#
# This is the server logic of a Shiny web application. You can run the
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(tidyverse)
library(lubridate)
library(sf)

# Lógica de datos del dashboard -------------------------------------------

shinyServer(function(input, output) {
    
    # Carga de datos ----------------------------------------------------------
    
    denuncias <- st_read("datos/denuncias.gpkg", stringsAsFactors = FALSE)
    delitos <- read_csv("datos/delitos.csv", locale = locale(encoding = "UTF-8"))
    poligono <- st_read("datos/poligono.gpkg", stringsAsFactors = FALSE)
    

    # Datos filtrados con los parámetros --------------------------------------

    denuncias_seleccion <- reactive({
        
        # Ajustar el mes seleccionado en el control, al primer día del mes:
        mes_seleccionado <- make_date(year(input$mes),
                                      month(input$mes),
                                      1)
        
        # Filtrar los datos con los parámetros seleccionados:
        denuncias %>%
            filter(categoria_ == input$delito
                   & mes_hech_ == mes_seleccionado)
        
    })
    
    
    # Cajas de totales --------------------------------------------------------

    output$total_mensual <- renderValueBox({

        # Contar el total de los delitos filtrados:
        total_denuncias <-
            denuncias_seleccion() %>%
            as_tibble() %>%
            count()
        
        # Visualizar en una caja de valor:
        valueBox(value = total_denuncias,
                 subtitle = "Delitos en el mes",
                 icon = icon("calendar-check"))
            
    })
    
    output$promedio_diario <- renderValueBox({
        
        # Contar el total de los delitos filtrados y dividir entre el número de días del mes:
        promedio <-
            denuncias_seleccion() %>%
            as_tibble() %>%
            count() /
            days_in_month(input$mes)
        
        # Visualizar en una caja de valor:
        valueBox(value = signif(promedio, 5),
                 subtitle = "Promedio diario",
                 icon = icon("calendar"))
        
    })

    
    # Mapa de incidencia ------------------------------------------------------
    
    output$mapa_incidencia <- renderLeaflet(
        
        # Visualizar los datos filtrados en el mapa:
        leaflet() %>%
            addTiles() %>%
            addPolygons(data = poligono) %>%
            addMarkers(data = denuncias_seleccion(),
                       popup = ~str_glue("<b>{titulo_delito}</b><br>
                                        <i>{delito_registrado}</i><br>
                                        {fecha_hechos}<br>
                                        {domicilio}<br>",
                                        titulo_delito = categoria_,
                                        delito_registrado = delito,
                                        fecha_hechos = fecha_hech_,
                                        domicilio = str_c(calle_hech, calle_he_1, colonia_he, sep = ", ")))
            
    )
    
})
