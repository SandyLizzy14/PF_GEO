#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(shinydashboard)
library(leaflet)


# Carga de catálogos ------------------------------------------------------

delitos <- 
    read_csv("datos/delitos.csv", locale = locale(encoding = "UTF-8")) %>%
    pull(categoria_)


# Diseño de la interfaz de usuario ----------------------------------------

shinyUI(
    
    dashboardPage(
        dashboardHeader(title = "Atlampa"),
        dashboardSidebar(disable = TRUE),
        dashboardBody(
            fluidRow(

                # Ventana de selección de parámetros --------------------------------------
    
                box(
                    column(width = 6,
                           selectInput("delito",
                                       label = "Delito",
                                       choices = delitos,
                                       selected = "ROBO A TRANSEUNTE EN VÍA PÚBLICA CON Y SIN VIOLENCIA")),
                    column(width = 6,
                           sliderInput("mes",
                                       label = "Mes",
                                       min = make_date(2019, 1, 1),
                                       max = make_date(2020, 4, 1),
                                       value = make_date(2020, 4, 1),
                                       step = period(1 , "month"),
                                       timeFormat = "%b %Y")),
                    title = "Parámetros",
                    width = 12
                ),

                
                # Ventana de visualización de resultados ----------------------------------

                box(
                    valueBoxOutput("total_mensual",
                                   width = 6),
                    valueBoxOutput("promedio_diario",
                                   width = 6),
                    leafletOutput("mapa_incidencia"),
                    title = "Incidencia delictiva",
                    width = 12
                )
                
            )
        )
    )
    
)